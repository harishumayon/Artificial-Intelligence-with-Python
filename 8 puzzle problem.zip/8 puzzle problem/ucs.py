import heapq
import time

def ucs(startarray, goalarray):
    startingtime = time.time()
    priority_queue = [(0, startarray, [])]
    visited = set()
    nodes_visited = 0  # Counter for total nodes visited

    while priority_queue:
        current_cost, current_state, path = heapq.heappop(priority_queue)

        if tuple(map(tuple, current_state)) in visited:
            continue

        nodes_visited += 1

        visited.add(tuple(map(tuple, current_state)))

        if check_eq(current_state, goalarray):
            print("FOUND")
            print_path(path)
            print("Total Nodes Visited:", nodes_visited)
            print("Path Cost:", len(path))
            endingtime = time.time()
            print("Time taken:", endingtime - startingtime, "seconds")
            return True

        neighbours = moves(current_state)

        for neighbour in neighbours:
            new_cost = current_cost + 1  # Assuming each move has a cost of 1
            heapq.heappush(priority_queue, (new_cost, neighbour, path + [current_state]))

    print("No solution found.")










def print_path(path):
    for state in path:
        print_state(state)
        print("-----")

def print_state(state):
    for row in state:
        print(row)

def trier(starray):
    r = -1
    c = -1
    for i in range(len(starray)):
        for j in range(len(starray[i])):
            if starray[i][j] == 0:
                r = i
                c = j
    return r, c

def check_eq(s, g):
    return (
        len(s) == len(g) and
        all(len(row_s) == len(row_g) for row_s, row_g in zip(s, g)) and
        all(element_s == element_g for row_s, row_g in zip(s, g) for element_s, element_g in zip(row_s, row_g))
    )

def moves(starray):
    row, column = trier(starray)
    neighbours = []

    if row > 0:
        temp = [row[:] for row in starray]
        temp[row][column], temp[row - 1][column] = temp[row - 1][column], temp[row][column]
        neighbours.append(temp)





    if column < 2:
        temp = [row[:] for row in starray]
        temp[row][column], temp[row][column + 1] = temp[row][column + 1], temp[row][column]
        neighbours.append(temp)

    if row < 2:
        temp = [row[:] for row in starray]
        temp[row][column], temp[row + 1][column] = temp[row + 1][column], temp[row][column]
        neighbours.append(temp)

    if column > 0:
        temp = [row[:] for row in starray]
        temp[row][column], temp[row][column - 1] = temp[row][column - 1], temp[row][column]
        neighbours.append(temp)

    return neighbours

#START STATE INPUT
user_input = input("Enter start state : ")

if len(user_input) != 9:
    print("Please enter exactly 9 digits.")
else:
    # Convert the string into a 2D array
    startarray = [[int(user_input[i * 3 + j]) for j in range(3)] for i in range(3)]

#GOALL STATE INPUT
user_input = input("Enter goall state : ")
if len(user_input) != 9:
    print("Please enter exactly 9 digits.")
else:
    # Convert the string into a 2D array
    goalarray = [[int(user_input[i * 3 + j]) for j in range(3)] for i in range(3)]



    # Print the 2D array
    print("The goal array :: ")
    for row in goalarray:
        print(row)

ucs(startarray, goalarray)
