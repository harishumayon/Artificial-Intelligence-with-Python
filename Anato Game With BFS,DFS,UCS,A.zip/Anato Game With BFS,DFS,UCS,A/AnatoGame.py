from collections import deque
import heapq
from collections import namedtuple

State = namedtuple('State', ['matrix', 'safety', 'path_cost'])
def read_map_from_file(filename):
    # Function to read a matrix map from a text file
    with open(filename, 'r') as file:
        # Read lines and replace characters to create a 2D array
        map_matrix = []
        for line in file:
            row = []
            i = 0
            while i < len(line.strip()):
                if line[i:i + 3] == '---':
                    row.append('1')
                    i += 3
                elif line[i:i + 2] in '+ ':
                    row.append('1')
                    i += 2
                elif line[i] in '+':
                    row.append('1')
                    i += 1

                elif line[i:i + 2] == '| ':
                    row.append('1')
                    i += 2
                elif line[i:i + 2] == ' |':
                    row.append('1')
                    i += 2

                elif line[i:i + 2] == '  ':
                    row.append('0')
                    i += 2
                elif line[i] == ' ':
                    row.append('0')
                    i += 1
                elif line[i] == '|':
                    row.append('1')
                    i += 1
                elif line[i] == 'A':
                    row.append('A')
                    i += 1
                elif line[i] == 'W':
                    row.append('W')
                    i += 1
                elif line[i] == 'Z':
                    row.append('Z')
                    i += 1
                elif line[i] == 'S':
                    row.append('S')
                    i += 1
                else:
                    row.append(line[i])
                    i += 1
            map_matrix.append(row)

    return map_matrix

def heuristic_function(state, goal_matrix):
    current_position = find_position(state, 'A')
    goal_position = find_position(goal_matrix, 'S')

    if current_position == (-1, -1):
        return 0  # Return a default heuristic value

    return calculate_distance(current_position, goal_position)


def find_position(matrix, target):
    for i, row in enumerate(matrix):
        for j, element in enumerate(row):
            if element == target:
                return i, j
    return -1, -1  # Return a default position if the target is not found in the matrix


def calculate_distance(position1, position2):
    return abs(position1[0] - position2[0]) + abs(position1[1] - position2[1])

def a_star(obtainedmatrix):
    start_state = State(matrix=obtainedmatrix, safety=0, path_cost=0)
    heap = [(heuristic_function(obtainedmatrix, obtainedmatrix), start_state)]  # Include heuristic in the priority queue
    heapq.heapify(heap)
    visited = set()
    nodes_visited = 0

    while heap:
        current_state = heapq.heappop(heap)[1]
        if tuple(map(tuple, current_state.matrix)) in visited:
            continue

        nodes_visited += 1

        visited.add(tuple(map(tuple, current_state.matrix)))

        if check_eq(current_state.matrix, obtainedmatrix):
            printpath(current_state.matrix)
            print("ANATO SURVIVES")
            print("Total Nodes Visited:", nodes_visited)
            return True

        neighbours = moves(current_state.matrix, current_state.safety)

        for neighbour in neighbours:
            new_state = State(matrix=neighbour[0], safety=neighbour[1], path_cost=current_state.path_cost + 1)
            heuristic_value = heuristic_function(new_state.matrix, obtainedmatrix)  # Calculate heuristic value
            heapq.heappush(heap, (new_state.path_cost + heuristic_value, new_state))  # Include heuristic in the priority queue

    print("ANATO DOESNT SURVIVE")


def ucs(obtainedmatrix):
    start_state = State(matrix=obtainedmatrix, safety=0, path_cost=0)
    heap = [start_state]
    heapq.heapify(heap)
    visited = set()
    nodes_visited = 0

    while heap:
        current_state = heapq.heappop(heap)

        if tuple(map(tuple, current_state.matrix)) in visited:
            continue

        nodes_visited += 1

        visited.add(tuple(map(tuple, current_state.matrix)))

        if check_eq(current_state.matrix, obtainedmatrix):
            printpath(current_state.matrix)
            print("ANATO SURVIVES")
            print("Total Nodes Visited:", nodes_visited)
            return True

        neighbours = moves(current_state.matrix, current_state.safety)

        for neighbour in neighbours:
            new_state = State(matrix=neighbour[0], safety=neighbour[1], path_cost=current_state.path_cost + 1)
            heapq.heappush(heap, new_state)

    print("ANATO DOESNT SURVIVE")

def bfs(obtainedmatrix):
    startingsafetystatus = 0
    queue = deque([(obtainedmatrix, startingsafetystatus, [])])
    visited = set()
    nodes_visited = 0

    while queue:
        current_state, safetystatus, current_compare = queue.popleft()

        if tuple(map(tuple, current_compare)) in visited:
            continue

        nodes_visited += 1

        visited.add(tuple(map(tuple, current_compare)))

        if check_eq(current_state, obtainedmatrix):
            printpath(current_state)
            print("ANATO SURVIVES")
            print("Total Nodes Visited:", nodes_visited)
            return True

        neighbourss = moves(current_state, safetystatus)

        for neigh in neighbourss:
            queue.append((neigh[0], neigh[1], neigh[2]))

    print("ANATO DOESNT SURVIVE")

def dfs(obtainedmatrix):
    startingsafetystatus = 0
    stack = [(obtainedmatrix, startingsafetystatus, [])]
    visited = set()
    nodes_visited = 0

    while stack:
        current_state, safetystatus,current_compare = stack.pop()

        if tuple(map(tuple, current_compare)) in visited:
            continue

        nodes_visited += 1

        visited.add(tuple(map(tuple, current_compare)))

        if check_eq(current_state,obtainedmatrix):
            printpath(current_state)
            print("ANATO SURVIVES")
            print("Total Nodes Visited:", nodes_visited)
            return True

        neighbourss = moves(current_state, safetystatus)

        for neigh in neighbourss:
            stack.append((neigh[0], neigh[1],neigh[2]))

    print("ANATO DOESNT SURVIVE")

def check_eq(statematrixxx,obtainedmatrix):
    for i in range(len(statematrixxx)):
        for j in range(len(statematrixxx[i])):
            if statematrixxx[i][j] == 'G':
                return True
    return False

def trier(obtainedmatrix):
    r=0
    c=0
    for i in range(len(obtainedmatrix)):
        for j in range(len(obtainedmatrix[i])):
            if obtainedmatrix[i][j] == 'A':
                r ,c = i, j
    print(r)
    print(c)
    return r, c

def makerowmove(temp, temp2, original, nextto,column,safety,neighbours):
    if temp[nextto][column] == '0':
        temp[nextto][column] = 'A'
        temp[original][column] = 'P'  # P will represent the path taken
        temp2[nextto][column] = 'A'
        temp2[original][column] = '0'  # 0 for duplicates
        neighbours.append((temp,safety,temp2))
    elif temp[nextto][column] == 'W':
        safety = safety + 1
        temp[nextto][column] = 'A'
        temp[original][column] = 'P'
        temp2[nextto][column] = 'A'
        temp2[original][column] = '0'
        neighbours.append((temp,safety,temp2))
    elif temp[nextto][column] == 'Z':
        if safety >= 1:
            temp[nextto][column] = 'A'
            temp[original][column] = 'P'
            temp2[nextto][column] = 'A'
            temp2[original][column] = '0'
            safety = safety - 1
            neighbours.append((temp,safety,temp2))
    elif temp[nextto][column] == 'S':
        temp[original][column] = 'P'
        temp[nextto][column] = 'G'# will add G means it reaches S and above i will check that if matrix has G , i reached my goal state
        temp2[original][column] = 'P'
        temp2[nextto][column] = '0'
        neighbours.append((temp,safety,temp2))

def printpath(statematrixxx):
    for row in statematrixxx:
        for element in row:
            print(element, end=" ")
        print()

def makecolumnmove(temp,temp2,row,original, nextto,safety,neighbours):
    if temp[row][nextto] == '0':
        temp[row][nextto] = 'A'
        temp[row][original] = 'P'  # P will represent the path taken
        temp2[row][nextto] = 'A'
        temp2[row][original] = '0'  # 0 for duplicates
        neighbours.append((temp,safety,temp2))
    elif temp[row][nextto] == 'W':
        safety = safety + 1
        temp[row][nextto] = 'A'
        temp[row][original] = 'P'
        temp2[row][nextto] = 'A'
        temp2[row][original] = '0'
        neighbours.append((temp,safety,temp2))
    elif temp[row][nextto] == 'Z':
        if safety >= 1:
            temp[row][nextto] = 'A'
            temp[row][original] = 'P'
            temp[row][nextto] = 'A'
            temp[row][original] = '0'
            safety = safety - 1
            neighbours.append((temp,safety,temp2))
    elif temp[row][nextto] == 'S':
        temp[row][original] = 'P'
        temp[row][nextto] = 'G'  # will add G means it reaches S and above i will check that if matrix has G , i reached my goal state
        temp2[row][original] = 'P'
        temp2[row][nextto] = '0'
        neighbours.append((temp,safety,temp2))

def moves(statematrix , safetystatus):
    row, column = trier(statematrix)
    neighbours = []
    num_rows = len(statematrix)
    num_columns = len(statematrix[0]) if statematrix else 0




    if column < num_columns-1:
        safety = safetystatus
        temp = [numrow[:] for numrow in statematrix]
        temp2 = [numrow[:] for numrow in statematrix]  # for duplicates
        makecolumnmove(temp, temp2, row, column, column+1, safety, neighbours)

    if column > 0:
        safety = safetystatus
        temp = [numrow[:] for numrow in statematrix]
        temp2 = [numrow[:] for numrow in statematrix]  # for duplicates
        makecolumnmove(temp, temp2, row, column, column - 1, safety, neighbours)


    if row < num_rows-1:
        safety = safetystatus
        temp = [numrow[:] for numrow in statematrix]
        temp2 = [numrow[:] for numrow in statematrix]  # for duplicates
        makerowmove(temp, temp2,  row, row + 1,column, safety, neighbours)

    if row > 0:
        safety=safetystatus
        temp = [numrow[:] for numrow in statematrix] # for path
        temp2 = [numrow[:] for numrow in statematrix]  # for duplicates
        makerowmove(temp,temp2,row,row-1,column,safety,neighbours)



    return neighbours

def whatt(algorithm):
    if algorithm == 'dfs':
        return dfs(obtainedmatrix)
    elif algorithm == 'bfs':
        return bfs(obtainedmatrix)
    elif algorithm == 'ucs':
        return ucs(obtainedmatrix)
    else:
        return a_star(obtainedmatrix)


# Example usage
filename = 'sample.txt'
obtainedmatrix = read_map_from_file(filename)
# Print the resulting 2D array
print("The start matrix")
for row in obtainedmatrix:
    print(row)

user_input = input("Which algos to use : ")
whatt(user_input)



